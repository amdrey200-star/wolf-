package com.wolfarmor;

import eu.pb4.trinkets.api.TrinketsApi;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WolfArmorSlotMod implements ModInitializer {

    public static final String MOD_ID = "wolfarmor";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[WolfArmorSlot] Initialising — wolf armor immortality active.");

        // Register our Trinket implementation for wolf_armor items.
        // TrinketsApi.registerTrinket maps an Item → Trinket behaviour object.
        // The actual damage-interception is done in LivingEntityMixin.
        TrinketsApi.registerTrinket(
                net.minecraft.world.item.Items.WOLF_ARMOR,
                new WolfArmorTrinket()
        );
    }
}
