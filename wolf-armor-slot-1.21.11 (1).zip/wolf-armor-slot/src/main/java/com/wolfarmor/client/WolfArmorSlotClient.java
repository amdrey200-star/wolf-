package com.wolfarmor.client;

import com.wolfarmor.WolfArmorSlotMod;
import net.fabricmc.api.ClientModInitializer;

public class WolfArmorSlotClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        WolfArmorSlotMod.LOGGER.info("[WolfArmorSlot] Client initialised.");
        // Trinkets Updated handles rendering the slot UI automatically.
        // Add a custom renderer here if you want the armor to visually
        // appear on the player model (see Trinkets' TrinketRenderer API).
    }
}
